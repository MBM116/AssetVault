"use strict";

document.addEventListener("DOMContentLoaded", () => {
    var recentlyViewed = {};

    (function () {
        var $this;
  
        recentlyViewed = {
            productHandle : null,
            rvCookie: null,
            rvProducts: [],
            displayProducts: [],
            rvProductArray: [],

            /*
			 * Initialize
			 */
			init: function () {

                $this = recentlyViewed;

                const productSection = document.querySelector(".js-product_section[data-rv-handle]");
                const rvProductSection = document.querySelector(".recently-viewed__section"); 
                if (productSection) {
                    $this.productHandle = productSection.dataset.rvHandle.toString();
                    $this.rvCookie = $this.getCookie("recentlyViewed");
                    $this.rvProducts = $this.getCookieProducts($this.rvCookie, $this.productHandle);
                } else if (rvProductSection) {
                    $this.rvCookie = $this.getCookie("recentlyViewed");
                    $this.rvProducts = $this.getCookieProducts($this.rvCookie, $this.productHandle);
                }

                if ($this.rvProducts) {
                    $this.rvProductArray = unescape($this.rvProducts).split(',');
                }

                if ($this.productHandle) {
                    if (!$this.rvProductArray.indexOf($this.productHandle) !== -1) {
                        $this.displayProducts = [];
                        $this.rvProductArray.unshift($this.productHandle);
                        $this.rvProductArray.forEach((el, _i) => {
                            if ($this.displayProducts.indexOf(el) === -1) $this.displayProducts.push(el);
                        });
                    }

                    $this.setCookieProducts($this.displayProducts);
                } else {
                    $this.displayProducts = $this.rvProductArray;
                }
                
                const recentlyViewedSections = document.querySelectorAll(".recently-viewed__section");
                if (recentlyViewedSections.length > 0) {
                    const parent = ".js-recently-viewed";
                    recentlyViewedSections.forEach(el => {
                        
                        if (el.querySelector(".rv-main")) {
                            $this.getProductInformation(el, $this.displayProducts, $this.productHandle);
                        }
                    });
                }
            },

            /*
			 * Get Cookie Products
			 */
            getCookieProducts: function(rvCookie, productHandle) {
                if (!rvCookie && productHandle) {
                    $this.setCookie("recentlyViewed", productHandle, { expires: 30, path: '/', sameSite: 'None', secure: true });
                    rvCookie = $this.getCookie("recentlyViewed");
                } else {
                    rvCookie = $this.getCookie("recentlyViewed");
                }
              
                return rvCookie;
            },

            /*
			 * Set Cookie Products
			 */ 
            setCookieProducts: function(rvProductArray) {
                $this.setCookie("recentlyViewed", escape(rvProductArray.join(',')), { expires: 30, path: '/', sameSite: 'None', secure: true });
            },

            /*
			 * Display Recently Viewed Products
			 */ 
            getProductInformation: function(parent, displayProducts, productHandle) {

                const productLimit = parent.dataset.visibleProducts;
                
                if (productLimit && displayProducts) {
                    displayProducts = displayProducts.slice(0, productLimit);
                }
                
                if (displayProducts.length > 0) {
                    displayProducts.forEach((product, index) => {
                        if (product) {
                            parent.classList.remove("hidden");

                            fetch(`/products/${product}?view=rv`).then(function(response) {
                                return response.text();
                            }).then(function(data) {
                                var parser = new DOMParser();

                                var data = parser.parseFromString(data, "text/html");
                                
                                const rvProductHTML = data.querySelector(".js-recently-viewed-product");
                                if (rvProductHTML) {
                                    const rvProduct = rvProductHTML.innerHTML;
                                    const targetElement = parent.querySelector(`.rv-box-${index}`);
                                    
                                    // Check if the target product exists
                                    if (targetElement) {
                                        targetElement.innerHTML = rvProduct;
                                    }
                                }

                                
                                // if (rvProductHTML) {
                                //     const rvProduct = rvProductHTML.innerHTML;
                                    
                                //     parent.querySelector(`.rv-box-${index}`).innerHTML = rvProduct;
                                // }
                                
                            });
                        }
                    });
                  
                    setTimeout(function() {
                        parent.querySelectorAll('.grid__item').forEach((grid_item, index) => {
                          if (grid_item.innerHTML.trim() === "") {
                            grid_item.remove();
                          }
                        });
                        
                        const RecentlyViewer = parent.querySelector('[id^="RecentlyViewer"]');
                        if (RecentlyViewer) {
                          RecentlyViewer.resetPages();
                        }
                      
                        // var event = new CustomEvent("compareProducts:reinit");
                        // document.dispatchEvent(event);
                    }, 2000);
                }
                
            },

            /*
			 * Set cookie
			 */
			getCookie: function (name) {
				var matches = document.cookie.match(
					new RegExp(
						"(?:^|; )" +
							name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, "\\$1") +
							"=([^;]*)"
					)
				);
				return matches ? decodeURIComponent(matches[1]) : undefined;
			},

            /*
			 * Set cookie
			 */
			setCookie: function (name, value, options) {
				options = options || {};

				options.path = options.hasOwnProperty("path") ? options.path : "/";

				options.expires = parseInt(options.expires);

				if (typeof options.expires == "number" && options.expires) {
					options.expires = new Date().setDate(
						new Date().getDate() + options.expires
					);

					options.expires = new Date(options.expires).toUTCString();
				}

				value = encodeURIComponent(value);

				var updatedCookie = name + "=" + value;

				for (var propName in options) {
					updatedCookie += "; " + propName;
					var propValue = options[propName];
					if (propValue !== true) {
						updatedCookie += "=" + propValue;
					}
				}

				document.cookie = updatedCookie;
			}
        }

    })();

    // Initialize.
	recentlyViewed.init();

    if (Shopify.designMode) {
        document.addEventListener('shopify:section:load', () => {
            recentlyViewed.init();
        });
    }
});