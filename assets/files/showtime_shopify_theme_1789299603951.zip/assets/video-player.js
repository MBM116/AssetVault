(async () => {
    const { Core } = await importModule('Core');
    const { Plyr } = await importModule('Plyr');

    customElements.define('video-player', class extends Core {
        subscriptions = {
            'dialog:closed': '_stop'
        };

        elements = {
            embeddedPlayer: '[data-player]',
            HTML5Player: 'video'
        }

        render() {
            this._initPlayer();
            this._handleDialogClose();
        }
        
        _initPlayer() {
            this.player = new Plyr(this.$player, {
                ratio: '16:9',
            });    
        }
        
        _handleDialogClose() {
            this.isPopup && this.subscribe('dialog:closed', { global: true });
        }

        _stop() {
            this.player.playing && this.player.stop();
        }

        get $player() {
            return this.$embeddedPlayer || this.$HTML5Player
        }

        get isPopup() {
            return this.hasAttribute('popup');
        }
    })
})();
