(async () => {
    const { Core } = await importModule('Core');

    customElements.define('product-variant-listener', class extends Core {
        subscriptions = {
            'variant:update': '_onVariantChange'
        }
        isMetaHidden = false;

        render() {
            this.emptyable = this.hasAttribute('emptyable');
            this.$meta = this.closest('[data-meta-block]');
            if (this.emptyable && this.isEmpty) {
                this._setMetaHidden();
            }

            this.subscribe('variant:update');
        }
        
        _onVariantChange({ targets }) {
            this._replaceContent(targets[this.id]);
            if(this.emptyable || this.isMetaHidden) {
                this._setMetaHidden();
            }
        }
        
        _replaceContent(to) {
            const target = to.content || to;
            this.replaceChildren(...target.cloneNode(true).childNodes);
        }

        _setMetaHidden(state) {
            this.isMetaHidden = state === undefined ? this.isEmpty : state;
            this.$meta.toggleAttribute('hidden', this.isMetaHidden);
        }

        get isEmpty() {
            return this.textContent.trim() === '';
        }
    })
})();
