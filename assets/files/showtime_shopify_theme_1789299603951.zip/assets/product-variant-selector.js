(async() => {
    const { Core } = await importModule('Core');
    customElements.define('product-variant-selector', class extends Core {
        
        render() {
            this.addEventListener('change', this._onVariantChange.bind(this));
        }
        
        _onVariantChange(e) {            
            this.publish('variant:change', {
                optionValueId: e.target.dataset.optionValueId, 
                optionIndex: e.target.dataset.optionIndex,
                variantId: e.target.dataset.variantId,
                imagePosition: e.target.dataset.imagePosition
            });
        }
    });
})()