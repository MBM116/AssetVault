(async() => {
    const { Core } = await importModule('Core');
    const {
        $JSON,
        cache,
        $fetch
    } = await importModule('Utils');

    const CACHE_KEY = 'variant-provider';

    function elementsToMap(elements) {
        return elements.reduce((acc, element) => {
            if (element.id) {
                acc[element.id] = element.cloneNode(true);
            }
            return acc;
        }, {});
    }

    class OptionsHistory {
        constructor(limit) {
            this.limit = limit;
            this.items = Array.from(Array(limit).keys());
        }
        add(item) {
            if(this.lastItem === item) {
                return;
            }
       
            const index = this.items.indexOf(item);
            this.items.splice(index, 1);
            this.items.push(item);
            // sanity chech
            if (this.items.length > this.limit) {
                this.items.shift();
            }
        }
        get lastItem() {
            return this.items.at(-1);
        }

        getValidOption(options) {
            for (const optionIndex of this.items) {
                // If matching option index comes from the last item, it means selection 
                // from other(previous) options failed to find it, hence the next selection 
                // will not include a variant with the last item option id
                if(options[optionIndex] && this.lastItem !== optionIndex) {
                    return {
                        ...options[optionIndex],
                        optionIndex
                    }
                }
            }
            return null;
        }
    }

    customElements.define('product-variant-provider', class extends Core {
        elements = {
            productMeta: '[data-product-meta]',
            listeners: '*product-variant-listener'
        }

        subscriptions = {
            'selling-plan:change': '_onSellingPlanChange',
            'variant:change': '_changeVariant',
        }

        render() {
            this.smartSelect = !this.hasAttribute('allow-unavailable-variants');
            this.disableCache = this.hasAttribute('no-cache');
            this.subscribe('variant:change');
            this.subscribe('selling-plan:change');
            this._initState();
        }

        async _initState() {
            this.currentState = { 
                variantId: this.initialVariantId,
                optionValueIds: this.initialOptionsState.split(','),
                variantImagePosition: this.initialImagePosition,
                sellingPlanId: this.initialSellingPlan
            };
            if (this.smartSelect) {
                this.optionsHistory = new OptionsHistory(this.currentState.optionValueIds.length);
            }
            this._initCache();
        }

        _initCache() {
            if(this.disableCache) {
                return;
            }
            if (!cache.has(this._cacheKey)) {
                cache.set(this._cacheKey, {
                    listeners: elementsToMap(this.$listeners)
                });
                return;
            }
            // if we have cache on initilization it's mean this cache was initited by someone before
            // refresh contents on the next tick
            setTimeout(() => {
                this._publishUpdates();
            }, 20)
        }

        _changeVariant({ optionValueId, optionIndex, variantId, imagePosition }) {         
            this.currentState.optionValueIds[+optionIndex] = optionValueId;        
            this.currentState.variantId = variantId || undefined;
            this.currentState.variantImagePosition = imagePosition;
            
            this.optionsHistory?.add(+optionIndex);
            this._handleUpdate();
        }

        async _handleUpdate() {
            await this._updateCache();
            this._publishUpdates();
            this._updateProps();
            if (this.isProductPage) {
                this._updateBrowserHistory();
            }
        }

        async _updateCache() {
            if (cache.has(this._cacheKey) && !this.disableCache) return;
            const $listeners = await this._fetchDoc();
            if($listeners) {
                cache.set(this._cacheKey, {
                    listeners: elementsToMap($listeners),
                });
            }
        }

        _updateProps() {
            this.setAttribute('initial-variant-id', this.currentState.variantId);
            this.setAttribute('initial-image-position', this.currentState.variantImagePosition);
            this.setAttribute('initial-selling-plan', this.currentState.sellingPlanId);
        }

        _publishUpdates() {
            if(cache.has(this._cacheKey)) {
                this.publish('variant:update', {
                    imagePosition: this.currentState.variantImagePosition,
                    targets: cache.get(this._cacheKey).listeners      
                })
            }
        }

        get _cacheKey() {
            return `${CACHE_KEY}-${this.sectionId}-${this.currentState.variantId}-${this.optionValueIdsString}-${this.currentState.sellingPlanId}`;
        }

        get optionValueIdsString() {
            return this.currentState.optionValueIds.toString();
        }

        async _fetchDoc() {
            const $doc = await $fetch(this.productURL, {
                before: this._loading(true),
                after: this._loading(false),
                params: {
                    selling_plan: this.currentState.sellingPlanId,
                    section_id: this.sectionId,
                    option_values: this.optionValueIdsString,
                },
                select: `#${this.id}`
            })

            if (this.smartSelect && !this.currentState.variantId) {
                const $availableOptionsJSON = $doc.querySelector('[data-available-options-json]'); 
                if (this._smartSelectVariant($availableOptionsJSON)) {    
                    // We will get a doc from the next _fetch iteration initiated by smart select
                    return null;
                } 
            }             
            return this._getListenersFromDoc($doc);
        }


        _getListenersFromDoc($doc) {
            return Array.from($doc.querySelectorAll('product-variant-listener'));
        }

        _loading(state) {
            return () => {
                this.publish('variant:loading', state);
            }
        }

        _smartSelectVariant(optionsJSON) {
            if(!optionsJSON) {
                console.error('JSON schema for smart select variants is missing');
                return false;
            }

            let options;
            try {
                options = $JSON(optionsJSON);
            } catch (e) {
                console.error(e);
                return false;
            }

            const matchOption = this.optionsHistory.getValidOption(options);

            if(!matchOption) {
                return false;
            }

            this._changeVariant(matchOption)
            return true;

        }

        _updateBrowserHistory() {
            window.history.replaceState({}, null, `${window.location.pathname}?${this.browserHistoryURLParams.toString()}`);
        }

        _onSellingPlanChange({ sellingPlanId }) {
            this.currentState.sellingPlanId = sellingPlanId;
            this._handleUpdate();
        }

        get browserHistoryURLParams() {
            const URLParams = new URLSearchParams({});
            if (this.currentState.variantId) {
                URLParams.set('variant', this.currentState.variantId);
            }
            // if (!this.currentState.variantId) { //NOTE: leave this here for now. The Dawn avoids this.
            //     URLParams.set('option_values', this.optionValueIdsString);
            // }
            this.currentState.sellingPlanId ? URLParams.set('selling_plan', this.currentState.sellingPlanId) : URLParams.delete('selling_plan');
            return new URLSearchParams(URLParams);
        }

        get isProductPage() {
            return this.hasAttribute('product-page');
        }
        get productURL() {
            return this.getAttribute('product-url');
        }
        get initialVariantId() {
            return this.getAttribute('initial-variant-id');
        }
        get initialImagePosition() {
            return this.getAttribute('initial-image-position');
        }
        get initialSellingPlan() {
            return this.getAttribute('initial-selling-plan');
        }
        get initialOptionsState() {
            return this.getAttribute('initial-options-state');
        }

    });
})()