class sidebarFiltersForm extends HTMLElement {
    constructor() {
        super();
        this.onActiveFilterClick = this.onActiveFilterClick.bind(this);

        this.debouncedOnSubmit = debounce((event) => {
            this.onSubmitHandler(event);
        }, 500);
        
        if(this.querySelector('form')){
            this.querySelector('form').addEventListener('input', this.debouncedOnSubmit.bind(this));
        }
        const sidebarWrapper = this.querySelector('#sidebarWrapperDesktop');
        if (sidebarWrapper) sidebarWrapper.addEventListener('keyup', onKeyUpEscape);
    }

    static setListeners() {
        const onHistoryChange = (event) => {
            const searchParams = event.state ? event.state.searchParams : sidebarFiltersForm.searchParamsInitial;
            if (searchParams === sidebarFiltersForm.searchParamsPrev) return;
            sidebarFiltersForm.renderPage(searchParams, null, false);
        }
        window.addEventListener('popstate', onHistoryChange);
    }

    static toggleActivesidebar(disable = true) {
        document.querySelectorAll('.js-sidebar-remove').forEach((element) => {
            element.classList.toggle('disabled', disable);
        });
    }

    static renderPage(searchParams, event, updateURLHash = true) {
        sidebarFiltersForm.searchParamsPrev = searchParams;
        const sections = sidebarFiltersForm.getSections();
        const countContainer = document.getElementById('ProductCount');
        const countContainerDesktop = document.getElementById('ProductCountDesktop');
        document.getElementById('ProductGridContainer').querySelector('.collection').classList.add('loading');
        if (countContainer) {
            countContainer.classList.add('loading');
        }
        if (countContainerDesktop) {
            countContainerDesktop.classList.add('loading');
        }

        sections.forEach((section) => {
            const url = `${window.location.pathname}?section_id=${section.section}&${searchParams}`;
            const filterDataUrl = element => element.url === url;

            sidebarFiltersForm.filterData.some(filterDataUrl) ?
                sidebarFiltersForm.renderSectionFromCache(filterDataUrl, event) :
                sidebarFiltersForm.renderSectionFromFetch(url, event);
        });

        if (updateURLHash) sidebarFiltersForm.updateURLHash(searchParams);
    }

    static renderSectionFromFetch(url, event) {
        fetch(url)
            .then(response => response.text())
            .then((responseText) => {
                const html = responseText;
                sidebarFiltersForm.filterData = [...sidebarFiltersForm.filterData, { html, url }];
                sidebarFiltersForm.renderFilters(html, event);
                sidebarFiltersForm.renderProductGridContainer(html);
                sidebarFiltersForm.renderProductCount(html);
            });
    }

    static renderSectionFromCache(filterDataUrl, event) {
        const html = sidebarFiltersForm.filterData.find(filterDataUrl).html;
        sidebarFiltersForm.renderFilters(html, event);
        sidebarFiltersForm.renderProductGridContainer(html);
        sidebarFiltersForm.renderProductCount(html);
    }

    static renderProductGridContainer(html) {
        document.getElementById('ProductGridContainer').innerHTML = new DOMParser().parseFromString(html, 'text/html').getElementById('ProductGridContainer').innerHTML;
    }

    static renderProductCount(html) {
        const count = new DOMParser().parseFromString(html, 'text/html').getElementById('ProductCount').innerHTML
        const container = document.getElementById('ProductCount');
        const containerDesktop = document.getElementById('ProductCountDesktop');
        container.innerHTML = count;
        container.classList.remove('loading');
        if (containerDesktop) {
            containerDesktop.innerHTML = count;
            containerDesktop.classList.remove('loading');
        }
    }

    static renderFilters(html, event) {
        const parsedHTML = new DOMParser().parseFromString(html, 'text/html');

        const sidebarDetailsElements =
            parsedHTML.querySelectorAll('#sidebarFiltersForm .js-filter, #sidebarFiltersFormMobile .js-filter');
        const matchesIndex = (element) => {
            const jsFilter = event ? event.target.closest('.js-filter') : undefined;
            return jsFilter ? element.dataset.index === jsFilter.dataset.index : false;
        }
        const sidebarToRender = Array.from(sidebarDetailsElements).filter(element => !matchesIndex(element));
        const countsToRender = Array.from(sidebarDetailsElements).find(matchesIndex);

        sidebarToRender.forEach((element) => {
            document.querySelector(`.js-filter[data-index="${element.dataset.index}"]`).innerHTML = element.innerHTML;
        });

        sidebarFiltersForm.renderActivesidebar(parsedHTML);
        sidebarFiltersForm.renderAdditionalElements(parsedHTML);

        if (countsToRender) sidebarFiltersForm.renderCounts(countsToRender, event.target.closest('.js-filter'));
    }

    static renderActivesidebar(html) {
        const activesidebarElementSelectors = ['.active-sidebar-mobile', '.active-sidebar-desktop'];

        activesidebarElementSelectors.forEach((selector) => {
            const activesidebarElement = html.querySelector(selector);
            if (!activesidebarElement) return;
            document.querySelector(selector).innerHTML = activesidebarElement.innerHTML;
        })

        sidebarFiltersForm.toggleActivesidebar(false);
    }

    static renderAdditionalElements(html) {
        const mobileElementSelectors = ['.mobile-sidebar__open', '.mobile-sidebar__count', '.sorting'];

        mobileElementSelectors.forEach((selector) => {
            if (!html.querySelector(selector)) return;
            document.querySelector(selector).innerHTML = html.querySelector(selector).innerHTML;
        });

        document.getElementById('sidebarFiltersFormMobile').closest('menu-drawer').bindEvents();
    }

    static renderCounts(source, target) {
        const targetElement = target.querySelector('.sidebar__selected');
        const sourceElement = source.querySelector('.sidebar__selected');

        if (sourceElement && targetElement) {
            target.querySelector('.sidebar__selected').outerHTML = source.querySelector('.sidebar__selected').outerHTML;
        }
    }

    static updateURLHash(searchParams) {
        history.pushState({ searchParams }, '', `${window.location.pathname}${searchParams && '?'.concat(searchParams)}`);
    }

    static getSections() {
        return [{
            section: document.getElementById('product-grid').dataset.id,
        }]
    }

    onSubmitHandler(event) {
        event.preventDefault();
        const formData = new FormData(event.target.closest('form'));
        const searchParams = new URLSearchParams(formData).toString();
        sidebarFiltersForm.renderPage(searchParams, event);
    }

    onActiveFilterClick(event) {
        event.preventDefault();
        sidebarFiltersForm.toggleActivesidebar();
        const url = event.currentTarget.href.indexOf('?') == -1 ? '' : event.currentTarget.href.slice(event.currentTarget.href.indexOf('?') + 1);
        sidebarFiltersForm.renderPage(url);
    }
}

sidebarFiltersForm.filterData = [];
sidebarFiltersForm.searchParamsInitial = window.location.search.slice(1);
sidebarFiltersForm.searchParamsPrev = window.location.search.slice(1);
customElements.define('sidebar-filters-form', sidebarFiltersForm);
sidebarFiltersForm.setListeners();

class PriceRange extends HTMLElement {
    constructor() {
        super();
        this.querySelectorAll('input').forEach(element => element.addEventListener('input', this.onRangeChange.bind(this)));
    }

    onRangeChange(event) {
        function handleRangeElements(className, idName) {
          if (document.querySelector(className)) {
            let val = document.querySelector(className).value;
            document.getElementById(idName).innerHTML = val;
    
            document.querySelector(className).addEventListener('change', function() {
              let val = this.value;
              document.getElementById(idName).innerHTML = val;
            });
          }
        }
        
        handleRangeElements('.range_from2', 'range_from2');
        handleRangeElements('.range_from', 'range_from');
        
        handleRangeElements('.mobilerange_from2', 'mobilerange_from2');
        handleRangeElements('.mobilerange_from', 'mobilerange_from');   
    }
}

customElements.define('price-range', PriceRange);

class sidebarRemove extends HTMLElement {
    constructor() {
        super();
        this.querySelector('a').addEventListener('click', (event) => {
            event.preventDefault();
            const form = this.closest('sidebar-filters-form') || document.querySelector('sidebar-filters-form');
            form.onActiveFilterClick(event);
        });
    }
}

customElements.define('sidebar-remove', sidebarRemove);