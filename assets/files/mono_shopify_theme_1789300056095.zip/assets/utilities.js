/**
 * Request an idle callback or fallback to setTimeout
 * @returns {function} The requestIdleCallback function
 */
export const requestIdleCallback =
  typeof window.requestIdleCallback == 'function' ? window.requestIdleCallback : setTimeout;


/**
 * Preloads an image
 * @param {string} src - The source of the image to preload
 */
export function preloadImage(src) {
  const image = new Image();
  image.src = src;
}


/**
 * @typedef {{ [key: string]: string | undefined }} Headers
 */

/**
 * @typedef {Object} FetchConfig
 * @property {string} method
 * @property {Headers} headers
 * @property {string | FormData | undefined} [body]
 */

/**
 * Creates a fetch configuration object
 * @param {string} [type] The type of response to expect
 * @param {Object} [config] The config of the request
 * @param {FetchConfig['body']} [config.body] The body of the request
 * @param {FetchConfig['headers']} [config.headers] The headers of the request
 * @returns {RequestInit} The fetch configuration object
 */
export function fetchConfig(type = 'json', config = {}) {
  /** @type {Headers} */
  const headers = { 'Content-Type': 'application/json', Accept: `application/${type}`, ...config.headers };

  if (type === 'javascript') {
    headers['X-Requested-With'] = 'XMLHttpRequest';
    delete headers['Content-Type'];
  }

  return {
    method: 'POST',
    headers: /** @type {HeadersInit} */ (headers),
    body: config.body,
  };
}

/**
 * Starts a view transition
 * @param {() => void} callback The callback to call when the view transition starts
 * @param {string[]} [types] The types of view transition to use
 * @returns {Promise<void>} A promise that resolves when the view transition finishes
 */
export function startViewTransition(callback, types) {
  return new Promise(async (resolve) => {
    // Check if View Transitions API is supported
    if (supportsViewTransitions() && !prefersReducedMotion()) {
      let cleanupFunctions = [];

      if (types) {
        for (const type of types) {
          if (viewTransitionTypes[type]) {
            const cleanupFunction = await viewTransitionTypes[type]();
            if (cleanupFunction) cleanupFunctions.push(cleanupFunction);
          }
        }
      }

      const transition = document.startViewTransition(callback);

      if (!viewTransition.current) {
        viewTransition.current = transition.finished;
      }

      if (types) types.forEach((type) => transition.types.add(type));

      transition.finished.then(() => {
        viewTransition.current = undefined;
        cleanupFunctions.forEach((cleanupFunction) => cleanupFunction());
        resolve();
      });

      return;
    }

    // Fallback for browsers that don't support this API yet
    callback();
    resolve();
  });
}