function getFocusableElements(container) {
  return Array.from(
    container.querySelectorAll(
      "summary, a[href], button:enabled, [tabindex]:not([tabindex^='-']), [draggable], area, input:not([type=hidden]):enabled, select:enabled, textarea:enabled, object, iframe"
    )
  );
}

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function throttle(fn, delay) {
  let lastCall = 0;
  return function (...args) {
    const now = new Date().getTime();
    if (now - lastCall < delay) {
      return;
    }
    lastCall = now;
    return fn(...args);
  };
}

function fetchConfig(type = 'json') {
  return {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: `application/${type}` },
  };
}

document.querySelectorAll('[id^="Details-"] summary').forEach((summary) => {
    summary.setAttribute('role', 'button');
    summary.setAttribute('aria-expanded', summary.parentNode.hasAttribute('open'));

    if (summary.nextElementSibling.getAttribute('id')) {
        summary.setAttribute('aria-controls', summary.nextElementSibling.id);
    }

    summary.addEventListener('click', (event) => {
        event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
    });

    if (summary.closest('header-drawer')) return;
    summary.parentElement.addEventListener('keyup', onKeyUpEscape);
});

const trapFocusHandlers = {};

function trapFocus(container, elementToFocus = container) {
    var elements = getFocusableElements(container);
    var first = elements[0];
    var last = elements[elements.length - 1];

    removeTrapFocus();

    trapFocusHandlers.focusin = (event) => {
        if (
          event.target !== container &&
          event.target !== last &&
          event.target !== first
        )
        return;
        document.addEventListener('keydown', trapFocusHandlers.keydown);
    };

    trapFocusHandlers.focusout = function() {
        document.removeEventListener('keydown', trapFocusHandlers.keydown);
    };

    trapFocusHandlers.keydown = function(event) {
        if (event.code.toUpperCase() !== 'TAB') return; // If not TAB key
        // On the last focusable element and tab forward, focus the first element.
        if (event.target === last && !event.shiftKey) {
            event.preventDefault();
            first.focus();
        }

        //  On the first focusable element and tab backward, focus the last element.
        if (
            (event.target === container || event.target === first) &&
            event.shiftKey
        ) {
            event.preventDefault();
            last.focus();
        }
    };

    document.addEventListener('focusout', trapFocusHandlers.focusout);
    document.addEventListener('focusin', trapFocusHandlers.focusin);

    elementToFocus.focus();
}

// Here run the querySelector to figure out if the browser supports :focus-visible or not and run code based on it.
try {
    document.querySelector(":focus-visible");
} catch (e) {
    focusVisiblePolyfill();
}

function focusVisiblePolyfill() {
    const navKeys = ['ARROWUP', 'ARROWDOWN', 'ARROWLEFT', 'ARROWRIGHT', 'TAB', 'ENTER', 'SPACE', 'ESCAPE', 'HOME', 'END', 'PAGEUP', 'PAGEDOWN']
    let currentFocusedElement = null;
    let mouseClick = null;

    window.addEventListener('keydown', (event) => {
      if (navKeys.includes(event.code.toUpperCase())) {
        mouseClick = false;
      }
    });

    window.addEventListener('mousedown', (event) => {
      mouseClick = true;
    });

    window.addEventListener('focus', () => {
      if (currentFocusedElement) currentFocusedElement.classList.remove('focused');

      if (mouseClick) return;

      currentFocusedElement = document.activeElement;
      currentFocusedElement.classList.add('focused');

    }, true);
}

function pauseAllMedia() {
    document.querySelectorAll('.js-youtube').forEach((video) => {
      video.contentWindow.postMessage('{"event":"command","func":"' + 'pauseVideo' + '","args":""}', '*');
    });
    document.querySelectorAll('.js-vimeo').forEach((video) => {
      video.contentWindow.postMessage('{"method":"pause"}', '*');
    });
    document.querySelectorAll('video').forEach((video) => video.pause());
    document.querySelectorAll('product-model').forEach((model) => {
      if (model.modelViewerUI) model.modelViewerUI.pause();
    });
}

function removeTrapFocus(elementToFocus = null) {
  document.removeEventListener('focusin', trapFocusHandlers.focusin);
  document.removeEventListener('focusout', trapFocusHandlers.focusout);
  document.removeEventListener('keydown', trapFocusHandlers.keydown);

  if (elementToFocus) elementToFocus.focus();
}

function onKeyUpEscape(event) {
  if (event.code.toUpperCase() !== 'ESCAPE') return;

  const openDetailsElement = event.target.closest('details[open]');
  if (!openDetailsElement) return;

  const summaryElement = openDetailsElement.querySelector('summary');
  openDetailsElement.removeAttribute('open');
  summaryElement.setAttribute('aria-expanded', false);
  summaryElement.focus();
}

class QuantityInput extends HTMLElement {
    constructor() {
      super();
      this.input = this.querySelector('input');
      this.changeEvent = new Event('change', { bubbles: true })

      this.querySelectorAll('button').forEach(
        (button) => button.addEventListener('click', this.onButtonClick.bind(this))
      );
    }

    onButtonClick(event) {
      event.preventDefault();
      const previousValue = this.input.value;

      event.target.name === 'plus' ? this.input.stepUp() : this.input.stepDown();
      if (previousValue !== this.input.value) this.input.dispatchEvent(this.changeEvent);
    }
}

customElements.define('quantity-input', QuantityInput);

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function fetchConfig(type = 'json') {
  return {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': `application/${type}` }
  };
}

/*
 * Shopify Common JS
 *
 */
if ((typeof window.Shopify) == 'undefined') {
  window.Shopify = {};
}

Shopify.bind = function(fn, scope) {
  return function() {
    return fn.apply(scope, arguments);
  }
};

Shopify.setSelectorByValue = function(selector, value) {
  for (var i = 0, count = selector.options.length; i < count; i++) {
    var option = selector.options[i];
    if (value == option.value || value == option.innerHTML) {
      selector.selectedIndex = i;
      return i;
    }
  }
};

Shopify.addListener = function(target, eventName, callback) {
  target.addEventListener ? target.addEventListener(eventName, callback, false) : target.attachEvent('on' + eventName, callback);
};

Shopify.postLink = function(path, options) {
  options = options || {};
  var method = options['method'] || 'post';
  var params = options['parameters'] || {};

  var form = document.createElement("form");
  form.setAttribute("method", method);
  form.setAttribute("action", path);

  for (var key in params) {
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", key);
    hiddenField.setAttribute("value", params[key]);
    form.appendChild(hiddenField);
  }
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

Shopify.CountryProvinceSelector = function(country_domid, province_domid, options) {
  this.countryEl = document.getElementById(country_domid);
  this.provinceEl = document.getElementById(province_domid);
  this.provinceContainer = document.getElementById(options['hideElement'] || province_domid);

  Shopify.addListener(this.countryEl, 'change', Shopify.bind(this.countryHandler, this));

  this.initCountry();
  this.initProvince();
};

Shopify.CountryProvinceSelector.prototype = {
    initCountry: function() {
      var value = this.countryEl.getAttribute('data-default');
      Shopify.setSelectorByValue(this.countryEl, value);
      this.countryHandler();
    },

    initProvince: function() {
      var value = this.provinceEl.getAttribute('data-default');
      if (value && this.provinceEl.options.length > 0) {
        Shopify.setSelectorByValue(this.provinceEl, value);
      }
    },

    countryHandler: function(e) {
      var opt = this.countryEl.options[this.countryEl.selectedIndex];
      var raw = opt.getAttribute('data-provinces');
      var provinces = JSON.parse(raw);

      this.clearOptions(this.provinceEl);
      if (provinces && provinces.length == 0) {
        this.provinceContainer.style.display = 'none';
      } else {
        for (var i = 0; i < provinces.length; i++) {
          var opt = document.createElement('option');
          opt.value = provinces[i][0];
          opt.innerHTML = provinces[i][1];
          this.provinceEl.appendChild(opt);
        }
        this.provinceContainer.style.display = "";
      }
    },

    clearOptions: function(selector) {
      while (selector.firstChild) {
        selector.removeChild(selector.firstChild);
      }
    },

    setOptions: function(selector, values) {
      for (var i = 0, count = values.length; i < values.length; i++) {
        var opt = document.createElement('option');
        opt.value = values[i];
        opt.innerHTML = values[i];
        selector.appendChild(opt);
      }
    }
};

class MenuDrawer extends HTMLElement {
    constructor() {
      super();
      this.mainDetailsToggle = this.querySelector('details');
      if (navigator.platform === 'iPhone') document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);
      this.addEventListener('keyup', this.onKeyUp.bind(this));
      this.addEventListener('focusout', this.onFocusOut.bind(this));
      this.bindEvents();
    }

    bindEvents() {
      this.querySelectorAll('summary').forEach(summary => summary.addEventListener('click', this.onSummaryClick.bind(this)));
      this.querySelectorAll('button').forEach(button => button.addEventListener('click', this.onCloseButtonClick.bind(this)));
    }

    onKeyUp(event) {
      if (event.code.toUpperCase() !== 'ESCAPE') return;
      const openDetailsElement = event.target.closest('details[open]');
      if (!openDetailsElement) return;
      openDetailsElement === this.mainDetailsToggle ? this.closeMenuDrawer(event, this.mainDetailsToggle.querySelector('summary')) : this.closeSubmenu(openDetailsElement);
    }

    onSummaryClick(event) {
      const summaryElement = event.currentTarget;
      const detailsElement = summaryElement.parentNode;
      const parentMenuElement = detailsElement.closest('.has-submenu');
      const isOpen = detailsElement.hasAttribute('open');
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
      function addTrapFocus() {
        trapFocus(summaryElement.nextElementSibling, detailsElement.querySelector('button'));
        summaryElement.nextElementSibling.removeEventListener('transitionend', addTrapFocus);
      }

      if (detailsElement === this.mainDetailsToggle) {
        if (isOpen) event.preventDefault();
        isOpen ? this.closeMenuDrawer(event, summaryElement) : this.openMenuDrawer(summaryElement);
      } else {
        setTimeout(() => {
          detailsElement.classList.add('menu-opening');
          summaryElement.setAttribute('aria-expanded', true);
          parentMenuElement && parentMenuElement.classList.add('submenu-open');
          !reducedMotion || reducedMotion.matches ? addTrapFocus() : summaryElement.nextElementSibling.addEventListener('transitionend', addTrapFocus);
        }, 100);
      }
    }

    openMenuDrawer(summaryElement) {
        setTimeout(() => {
            this.mainDetailsToggle.classList.add('menu-opening');
        });
        summaryElement.setAttribute('aria-expanded', true);
        trapFocus(this.mainDetailsToggle, summaryElement);
        document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
    }

    closeMenuDrawer(event, elementToFocus = false) {
        if (event === undefined) return;

        this.mainDetailsToggle.classList.remove('menu-opening');
        this.mainDetailsToggle.querySelectorAll('details').forEach(details => {
            details.removeAttribute('open');
            details.classList.remove('menu-opening');
        });
        this.mainDetailsToggle.querySelectorAll('.submenu-open').forEach(submenu => {
            submenu.classList.remove('submenu-open');
        });
        document.body.classList.remove(`overflow-hidden-${this.dataset.breakpoint}`);
        removeTrapFocus(elementToFocus);
        this.closeAnimation(this.mainDetailsToggle);
    }

    onFocusOut(event) {
        setTimeout(() => {
            if (this.mainDetailsToggle.hasAttribute('open') && !this.mainDetailsToggle.contains(document.activeElement)) this.closeMenuDrawer();
        });
    }

    onCloseButtonClick(event) {
        const detailsElement = event.currentTarget.closest('details');
        this.closeSubmenu(detailsElement);
    }

    closeSubmenu(detailsElement) {
        const parentMenuElement = detailsElement.closest('.submenu-open');
        parentMenuElement && parentMenuElement.classList.remove('submenu-open');
        detailsElement.classList.remove('menu-opening');
        detailsElement.querySelector('summary').setAttribute('aria-expanded', false);
        removeTrapFocus(detailsElement.querySelector('summary'));
        this.closeAnimation(detailsElement);
    }

    closeAnimation(detailsElement) {
        let animationStart;

        const handleAnimation = (time) => {
            if (animationStart === undefined) {
                animationStart = time;
            }
            const elapsedTime = time - animationStart;
            if (elapsedTime < 400) {
                window.requestAnimationFrame(handleAnimation);
            } else {
                detailsElement.removeAttribute('open');
                if (detailsElement.closest('details[open]')) {
                    trapFocus(detailsElement.closest('details[open]'), detailsElement.querySelector('summary'));
                }
            }
        }

        window.requestAnimationFrame(handleAnimation);
    }
}

customElements.define('menu-drawer', MenuDrawer);

class HeaderDrawer extends MenuDrawer {
  constructor() {
    super();
  }

  openMenuDrawer(summaryElement) {
    this.header = this.header || document.querySelector('.section-header');
    this.borderOffset = this.borderOffset || this.closest('.header-wrapper').classList.contains('header-wrapper--border-bottom') ? 1 : 0;
    document.documentElement.style.setProperty('--header-bottom-position', `${parseInt(this.header.getBoundingClientRect().bottom - this.borderOffset)}px`);
    this.header.classList.add('menu-open');

    setTimeout(() => {
      this.mainDetailsToggle.classList.add('menu-opening');
    });

    summaryElement.setAttribute('aria-expanded', true);
    window.addEventListener('resize', this.onResize);
    trapFocus(this.mainDetailsToggle, summaryElement);
    document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }

  closeMenuDrawer(event, elementToFocus) {
    if (!elementToFocus) return;
    super.closeMenuDrawer(event, elementToFocus);
    this.header.classList.remove('menu-open');
    window.removeEventListener('resize', this.onResize);
  }

  onResize = () => {
    this.header && document.documentElement.style.setProperty('--header-bottom-position', `${parseInt(this.header.getBoundingClientRect().bottom - this.borderOffset)}px`);
    document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);
  };
}

customElements.define('header-drawer', HeaderDrawer);

class ModalDialog extends HTMLElement {
  constructor() {
    super();
    this.querySelector('[id^="ModalClose-"]').addEventListener(
      'click',
      this.hide.bind(this, false)
    );
    this.addEventListener('keyup', (event) => {
      if (event.code.toUpperCase() === 'ESCAPE') this.hide();
    });
    if (this.classList.contains('media-modal')) {
      this.addEventListener('pointerup', (event) => {
        if (event.pointerType === 'mouse' && !event.target.closest('deferred-media, product-model')) this.hide();
      });
    } else {
      this.addEventListener('click', (event) => {
        if (event.target === this) this.hide();
      });
    }
  }

  connectedCallback() {
    if (this.moved) return;
    this.moved = true;
    document.body.appendChild(this);
  }

  show(opener) {
    this.openedBy = opener;
    const popup = this.querySelector('.template-popup');
    document.body.classList.add('overflow-hidden');
    this.setAttribute('open', '');
    if (popup) popup.loadContent();
    trapFocus(this, this.querySelector('[role="dialog"]'));
    window.pauseAllMedia();
  }

  hide() {
    document.body.classList.remove('overflow-hidden');
    document.body.dispatchEvent(new CustomEvent('modalClosed'));
    this.removeAttribute('open');
    removeTrapFocus(this.openedBy);
    window.pauseAllMedia();
  }
}
customElements.define('modal-dialog', ModalDialog);

class ModalOpener extends HTMLElement {
  constructor() {
    super();

    const button = this.querySelector('button');

    if (!button) return;
    button.addEventListener('click', () => {
      const modal = document.querySelector(this.getAttribute('data-modal'));
      if (modal) modal.show(button);
    });
  }
}
customElements.define('modal-opener', ModalOpener);

class DeferredMedia extends HTMLElement {
    constructor() {
        super();
        const poster = this.querySelector('[id^="Deferred-Poster-"]');
        if (!poster) return;
        poster.addEventListener('click', this.loadContent.bind(this));
    }

    loadContent(focus = true) {
        window.pauseAllMedia();
        if (!this.getAttribute('loaded')) {
            const content = document.createElement('div');
            content.appendChild(this.querySelector('template').content.firstElementChild.cloneNode(true));

            this.setAttribute('loaded', true);
            const deferredElement = this.appendChild(content.querySelector('video, model-viewer, iframe'));
            if (focus) deferredElement.focus();
        }
    }
}

customElements.define('deferred-media', DeferredMedia);

class SliderComponent extends HTMLElement {
    constructor() {
      super();
      this.slider = this.querySelector('[id^="Slider-"]');
      this.sliderItems = this.querySelectorAll('[id^="Slide-"]');
      this.enableSliderLooping = false;
      this.currentPageElement = this.querySelector('.slider-counter--current');
      this.pageTotalElement = this.querySelector('.slider-counter--total');
      this.prevButton = this.querySelector('button[name="previous"]');
      this.nextButton = this.querySelector('button[name="next"]');
      if (!this.slider || !this.nextButton) return;
      this.initPages();
      const resizeObserver = new ResizeObserver(entries => this.initPages());
      resizeObserver.observe(this.slider);
      this.slider.addEventListener('scroll', this.update.bind(this));
      this.prevButton.addEventListener('click', this.onButtonClick.bind(this));
      this.nextButton.addEventListener('click', this.onButtonClick.bind(this));
    }
  
    initPages() {
      this.sliderItemsToShow = Array.from(this.sliderItems).filter(element => element.clientWidth > 0);
      if (this.sliderItemsToShow.length < 2) return;
      this.sliderItemOffset = this.sliderItemsToShow[1].offsetLeft - this.sliderItemsToShow[0].offsetLeft;
      this.slidesPerPage = Math.floor((this.slider.clientWidth - this.sliderItemsToShow[0].offsetLeft) / this.sliderItemOffset);
      this.totalPages = this.sliderItemsToShow.length - this.slidesPerPage + 1;
      this.update();
    }
  
    resetPages() {
      this.sliderItems = this.querySelectorAll('[id^="Slide-"]');
      this.initPages();
    }
  
    update() {
      const previousPage = this.currentPage;
      this.currentPage = Math.round(this.slider.scrollLeft / this.sliderItemOffset) + 1;
      if (this.currentPageElement && this.pageTotalElement) {
        this.currentPageElement.textContent = this.currentPage;
        this.pageTotalElement.textContent = this.totalPages;
      }
      if (this.currentPage != previousPage) {
        this.dispatchEvent(new CustomEvent('slideChanged', { detail: {
          currentPage: this.currentPage,
          currentElement: this.sliderItemsToShow[this.currentPage - 1]
        }}));
      }
      if (this.enableSliderLooping) return;
      if (this.isSlideVisible(this.sliderItemsToShow[0]) && this.slider.scrollLeft === 0) {
        this.prevButton.setAttribute('disabled', 'disabled');
      } else {
        this.prevButton.removeAttribute('disabled');
      }
      if (this.isSlideVisible(this.sliderItemsToShow[this.sliderItemsToShow.length - 1])) {
        this.nextButton.setAttribute('disabled', 'disabled');
      } else {
        this.nextButton.removeAttribute('disabled');
      }
    }
  
    isSlideVisible(element, offset = 0) {
      const lastVisibleSlide = this.slider.clientWidth + this.slider.scrollLeft - offset;
      return (element.offsetLeft + element.clientWidth) <= lastVisibleSlide && element.offsetLeft >= this.slider.scrollLeft;
    }
  
    onButtonClick(event) {
      event.preventDefault();
      const step = event.currentTarget.dataset.step || 1;
      this.slideScrollPosition = event.currentTarget.name === 'next' ? this.slider.scrollLeft + (step * this.sliderItemOffset) : this.slider.scrollLeft - (step * this.sliderItemOffset);
      this.slider.scrollTo({
        left: this.slideScrollPosition
      });
    }
  }
  
customElements.define('slider-component', SliderComponent);

class VariantSelects extends HTMLElement {
    constructor() {
        super();
        this.addEventListener('change', this.onVariantChange);
    }

    onVariantChange() {
        this.updateOptions();
        this.updateMasterId();
        this.updateSelectedSwatchValue(event);
        this.toggleAddButton(true, '', false);
        this.updatePickupAvailability();
        if (!this.currentVariant) {
          this.toggleAddButton(true, '', true);
          this.setUnavailable();
        } else {
          this.rendorStickyCart();
          this.updateVariantInput();
          this.updateURL();
          this.renderProductInfo();
          this.rendorStickyCart();   
          this.updateMedia();
        }
    }

    updateOptions() {
      this.options = Array.from(this.querySelectorAll('select'), (select) => select.value);
    }

    updateMasterId() {
      this.currentVariant = this.getVariantData().find((variant) => {
        return !variant.options.map((option, index) => {
          return this.options[index] === option;
        }).includes(false);
      });      
    } 

    updateSelectedSwatchValue({ target }) {
      const { name, value, tagName } = target;

      if (tagName === 'SELECT' && target.selectedOptions.length) {
        const swatchValue = target.selectedOptions[0].dataset.optionSwatchValue;
        const selectedDropdownSwatchValue = this.querySelector(`[data-selected-dropdown-swatch="${name}"] > .swatch`);
        if (!selectedDropdownSwatchValue) return;
        if (swatchValue) {
          selectedDropdownSwatchValue.style.setProperty('--swatch--background', swatchValue);
          selectedDropdownSwatchValue.classList.remove('swatch--unavailable');
        } else {
          selectedDropdownSwatchValue.style.setProperty('--swatch--background', 'unset');
          selectedDropdownSwatchValue.classList.add('swatch--unavailable');
        }
      } else if (tagName === 'INPUT' && target.type === 'radio') {
        const selectedSwatchValue = this.querySelector(`[data-selected-swatch-value="${name}"]`);
        if (selectedSwatchValue) selectedSwatchValue.innerHTML = value;
      }
    }

    updateURL() {
      if (document.body.classList.contains('template-product')) {
        if (!this.currentVariant || this.dataset.updateUrl === 'false') return;
        window.history.replaceState({}, '', `${this.dataset.url}?variant=${this.currentVariant.id}`);
      }
    }

    updateMedia() {
      if (!this.currentVariant) return;
      if (!this.currentVariant.featured_media) return;
      const mediaGallery = document.getElementById(`MediaGallery-${this.dataset.section}`);
      mediaGallery.setActiveMedia(`${this.dataset.section}-${this.currentVariant.featured_media.id}`, true);
      const modalContent = document.querySelector(`#ProductModal-${this.dataset.section} .product-media-modal__content`);
      if (!modalContent) return;
      const newMediaModal = modalContent.querySelector(`[data-media-id="${this.currentVariant.featured_media.id}"]`);
      modalContent.prepend(newMediaModal);
    }

    updateVariantInput() {
      const productForms = document.querySelectorAll(`#product-form-${this.dataset.section}${this.dataset.product}, #product-form-installment-${this.dataset.section}`);
      productForms.forEach((productForm) => {
        const input = productForm.querySelector('input[name="id"]');
        input.value = this.currentVariant.id;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
  
    updatePickupAvailability() {
      if (document.body.classList.contains('template-product')) {    
        const pickUpAvailability = document.querySelector('pickup-availability');
        if (!pickUpAvailability) return;
        if (this.currentVariant && this.currentVariant.available) {
          pickUpAvailability.fetchAvailability(this.currentVariant.id);
        } else {
          pickUpAvailability.removeAttribute('available');
          pickUpAvailability.innerHTML = '';
        }
      }
    }

    removeErrorMessage() {
      const section = this.closest('section');
      if (!section) return;
      const productForm = section.querySelector('product-form');
      if (productForm) productForm.handleErrorMessage();
    }

    renderProductInfo() {
      fetch(`${this.dataset.url}?variant=${this.currentVariant.id}&section_id=${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section}`)
        .then((response) => response.text())
        .then((responseText) => {
          const html = new DOMParser().parseFromString(responseText, 'text/html')
          const destination = document.getElementById(`price-${this.dataset.product}`);
          const source = html.getElementById(`price-${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.product}`);
          if (source && destination) destination.innerHTML = source.innerHTML;
          const price = document.getElementById(`price-${this.dataset.product}`);
          if (price) price.classList.remove('visibility-hidden');
          this.toggleAddButton(!this.currentVariant.available, window.variantStrings.soldOut);
        });
    }

    toggleAddButton(disable = true, text, modifyClass = true) {
      const productForm = document.getElementById(`product-form-${this.dataset.section}${this.dataset.product}`);
      if (!productForm) return;
      const addButton = productForm.querySelector('[name="add"]');
      const addButtonText = productForm.querySelector('[name="add"] > span');
      if (!addButton) return;
      if (disable) {
        addButton.setAttribute('disabled', 'disabled');
        if (text) addButtonText.textContent = text;
      } else {
        addButton.removeAttribute('disabled');
        addButtonText.textContent = window.variantStrings.addToCart;
      }
      if (!modifyClass) return;
    }

    setUnavailable() {
      const button = document.getElementById(`product-form-${this.dataset.section}${this.dataset.product}`);
      const addButton = button.querySelector('[name="add"]');
      const addButtonText = button.querySelector('[name="add"] > span');
      const price = document.getElementById(`price-${this.dataset.product}`);
      if (!addButton) return;
      addButtonText.textContent = window.variantStrings.unavailable;
      if (price) price.classList.add('visibility-hidden');
    }

    getVariantData() {
      this.variantData = this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);
      return this.variantData;
    }

    rendorStickyCart() {
      if (document.querySelector("body").classList.contains("template-product")) {
        fetch(`${this.dataset.url}?variant=${this.currentVariant.id}&section_id=${this.dataset.section}`)
        .then((response) => response.text())
        .then((responseText) => {
            const imgName = `#sticky-${this.dataset.section} .sticky-image`;
            const imgHtml = new DOMParser().parseFromString(responseText, 'text/html')
            const imgDestination = document.querySelector(imgName);
            const imgSource = imgHtml.querySelector(imgName);
            if(imgDestination)
              imgDestination.innerHTML = imgSource.innerHTML;
            const options = `#sticky-${this.dataset.section} .sticky-title-flex`;
            const html = new DOMParser().parseFromString(responseText, 'text/html')
            const destination = document.querySelector(options);
            const source = html.querySelector(options);
            if(destination)
              destination.innerHTML = source.innerHTML;
            const stickyOptions = `#sticky-${this.dataset.section} .stickyOptions`;
            const stickyOptionshtml = new DOMParser().parseFromString(responseText, 'text/html')
            const stickyOptionsdestination = document.querySelector(stickyOptions);
            const stickyOptionssource = html.querySelector(stickyOptions);
            if(stickyOptionsdestination)
            stickyOptionsdestination.innerHTML = stickyOptionssource.innerHTML;
        });
      }
    }
}

customElements.define('variant-selects', VariantSelects);

class VariantRadios extends VariantSelects {
    constructor() {
        super();
    }

    updateOptions() {
        const fieldsets = Array.from(this.querySelectorAll('fieldset'));
        this.options = fieldsets.map((fieldset) => {
            return Array.from(fieldset.querySelectorAll('input')).find((radio) => radio.checked).value;
        });
    }
}

customElements.define('variant-radios', VariantRadios);

if (console && console.log) {
  console.log('Mono theme (1.2.0) by Slash Themes | Learn more at https://slashthemes.com/');
}

class StickyAddToCart extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('change', this.onVariantChange);
    this.eventListenerElement();
  }
  eventListenerElement(){
    window.addEventListener("scroll", (event) => {
      this.observerScroll();
    });
  }

  observerScroll() {
    var sticky = false;
    var top = window.scrollY;
    if (800 < top)
        this.classList.add('stickyCart-active');
    else{
      this.classList.remove('stickyCart-active');
      (document.querySelector('#back-to-up')) ? document.querySelector('#back-to-up').style.bottom = '10px' : '';
    }
  }
}
window.customElements.get("sticky-add-to-cart") || window.customElements.define('sticky-add-to-cart', StickyAddToCart);

/*============================================================================
    ImageCompare
  ==============================================================================*/
  
  class ImageCompare extends HTMLElement {
    constructor() {
      super();
      this.el = this;
      this.sectionId = this.dataset.sectionId;
      this.button = this.querySelector('[data-button]');
      this.draggableContainer = this.querySelector('[data-draggable]');
      this.primaryImage = this.querySelector('[data-primary-image]');
      this.secondaryImage = this.querySelector('[data-secondary-image]');  
      this.calculateSizes();  
      this.active = false;
      this.currentX = 0;
      this.initialX = 0;
      this.xOffset = 0;
      this.buttonOffset = this.button.offsetWidth / 2;  
      this.el.addEventListener("touchstart", this.dragStart, false);
      this.el.addEventListener("touchend", this.dragEnd, false);
      this.el.addEventListener("touchmove", this.drag, false);  
      this.el.addEventListener("mousedown", this.dragStart, false);
      this.el.addEventListener("mouseup", this.dragEnd, false);
      this.el.addEventListener("mousemove", this.drag, false);  
  
      document.addEventListener('shopify:section:load', event => {
        if (event.detail.sectionId === this.sectionId && this.primaryImage !== null) {
          this.calculateSizes();
        }
      });
    }
  
    calculateSizes(hasResized = false) {
      this.active = false;
      this.currentX = 0;
      this.initialX = 0;
      this.xOffset = 0;
  
      this.buttonOffset = this.button.offsetWidth / 2;
  
      this.elWidth = this.el.offsetWidth;
  
      this.button.style.transform = `translate(-${this.buttonOffset}px, -50%)`;
      this.primaryImage.style.width = `${this.elWidth}px`;
      if (hasResized) this.draggableContainer.style.width = `${this.elWidth/2}px`;
    }
  
    dragStart(e) {
      if (e.type === "touchstart") {
        this.initialX = e.touches[0].clientX - this.xOffset;
      } else {
        this.initialX = e.clientX - this.xOffset;
      }
  
      if (e.target === this.button) {
        this.active = true;
      }
    }
  
    dragEnd(e) {
      this.initialX = this.currentX;
  
      this.active = false;
    }
  
    drag(e) {
      if (this.active) {
  
        e.preventDefault();
  
        if (e.type === "touchmove") {
          this.currentX = e.touches[0].clientX - this.initialX;
        } else {
          this.currentX = e.clientX - this.initialX;
        }
  
        this.xOffset = this.currentX;
        this.setTranslate(this.currentX, this.button);
      }
    }
  
    setTranslate(xPos, el) {
      let newXpos = xPos - this.buttonOffset;
      let newVal = (this.elWidth/2) + xPos;
  
      const boundaryPadding = 0;
      const XposMin = (this.elWidth/2 + this.buttonOffset) * -1;
      const XposMax = this.elWidth/2 - this.buttonOffset;
  
      // Set boundaries for dragging
      if (newXpos < (XposMin + boundaryPadding)) {
        newXpos = XposMin + boundaryPadding;
        newVal = boundaryPadding
      } else if (newXpos > (XposMax - boundaryPadding)) {
        newXpos = XposMax - boundaryPadding;
        newVal = this.elWidth - boundaryPadding;
      }
  
      el.style.transform = `translate(${newXpos}px, -50%)`;
      this.draggableContainer.style.width = `${newVal}px`;
    }
  }
  
customElements.define('image-compare', ImageCompare);

class accordionTab extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('click', (event) => {
      event.preventDefault();
      if (this.classList.contains('block-collapsed')) {
        this.classList.remove('block-collapsed');
      } else {
        this.classList.add('block-collapsed');
      }
    });
     
      const handleResponsiveBehaviors = () => {
        const windowsWidth = window.innerWidth;

        if (windowsWidth < 750) {
          this.classList.add('accordion');
          this.classList.add('block-collapsed');
          this.querySelectorAll('svg.icon-caret.hidden').forEach((tabSvg) => {
            tabSvg.classList.remove('hidden');
          });
          this.parentNode.querySelectorAll('.footer-block__details-content').forEach((tabcontent) => {
            tabcontent.classList.add('accordion-mobile');
          });
        }
        if (windowsWidth > 750) {
          this.classList.remove('accordion');
          this.classList.remove('block-collapsed');
          this.querySelectorAll('svg.icon-caret').forEach((tabSvg) => {
            tabSvg.classList.add('hidden');
          });
          this.parentNode.querySelectorAll('.footer-block__details-content').forEach((tabcontent) => {
            tabcontent.classList.remove('accordion-mobile');
          });
        }
      };

    window.addEventListener('load', handleResponsiveBehaviors);
    let lastWidth = window.innerWidth;

    window.addEventListener('resize', () => {
      const currentWidth = window.innerWidth;
      if (currentWidth !== lastWidth) {
        lastWidth = currentWidth;
        handleResponsiveBehaviors();
      }
    });
  }
}

window.customElements.get("accordion-tab") || window.customElements.define("accordion-tab", accordionTab);

class Utils {
  static disable_prevent_scroll = !1;
  static disable_swipe_listener = !1;
  static scripts = {};
  static links = {};
  static areNumericStrings(...t) {
    return t.every((t) => /^[0-9]+$/.test(t));
  }
  static isValidEmail(t) {
    return /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(t);
  }
  static scriptLoader(t, e, i) {
    var s;
    void 0 === this.scripts[t] ? ((this.scripts[t] = "requested"), ((s = document.createElement("script")).src = e), (s.onload = () => {
        (this.scripts[t] = "loaded"), i && i(), window.trigger(`theme:${t}:loaded`);
      }),
      (document.body || document.head).appendChild(s)) : i && "requested" === this.scripts[t] ? window.on(`theme:${t}:loaded`, i) : i && "loaded" === this.scripts[t] && i();
  }
  static linkLoader(t, e, i, s) {
    var r;
    this.links[t] || (((r = document.createElement("link")).rel = e), (r.href = t), s && (r.as = s), i && (r.fetchPriority = i), document.head.appendChild(r), (this.links[t] = r));
  }
  static getFocusableEl(e = !1) {
    if (e) {
      let t = "";
      "small" === MediaQueries.current_window
        ? (t = ":not([data-mq='medium-large']):not([data-mq='medium']):not([data-mq='large'])")
        : "medium" === MediaQueries.current_window
        ? (t = ":not([data-mq='small']):not([data-mq='large'])")
        : "large" === MediaQueries.current_window && (t = ":not([data-mq='small-medium']):not([data-mq='small']):not([data-mq='medium'])");
      var i = `
      button:not([disabled]):not([aria-hidden='true']),
      [href]:not(link)${t},
      input:not([type='hidden']):not([disabled]):not([aria-hidden='true']),
      select:not([disabled]):not([data-mq='none']):not([aria-hidden='true']),
      textarea:not([disabled]),
      [tabindex]:not([tabindex='-1'])${t}
    `;
      return e.querySelectorAll(i);
    }
  }
  static getQuantity(t, { id: e, management: i, policy: s, quantity: r }, o) {
    if ("shopify" !== i || "continue" === s) return o;
    var a = Cart.basket[e] || 0;
    let n = parseInt(r) - a;
    if (n <= 0) (n = 0), window.trigger(`theme:product:${t}:updateQuantity`, 1);
    else {
      if (!(o > n)) return o;
      window.trigger(`theme:product:${t}:updateQuantity`, n);
    }
    return FeedbackBar.trigger("quantity", n), !1;
  }
  static updateRecentProducts(t) {
    var e = Shopify.theme.name + ":recent_products",
        i = [t],
        s = localStorage.getItem(e);
    let r,
        o,
        a = !1;
    s ? -1 === (r = JSON.parse(s)).indexOf(t) && (a = !0) : ((o = JSON.stringify(i)), localStorage.setItem(e, o)), a && (4 === r.length && (r = r.slice(1)), (o = JSON.stringify(r.concat(i))), localStorage.setItem(e, o));
  }
}

class CountdownTimer extends HTMLElement {
  constructor() {
    super();
  }
  connectedCallback() {
    (this.days_container = this.querySelector(".countdown-timer--item")),
        (this.digits = this.querySelectorAll(".countdown-timer--digit")),
        (this.hide_when_expired = "true" === this.getAttribute("data-hide-expired")),
        (this.show_button_when = this.getAttribute("data-show-button-when"));
    var t = this.getAttribute("data-expiry-date").split("-"),
        e = this.getAttribute("data-expiry-hours"),
        i = this.getAttribute("data-expiry-minutes");
    (this.countdown_date = this.initDate(...t, e, i)), this.initTimer(), this.startTimer(), this.addStateListener();
  }
  disconnectedCallback() {
    this.timer && clearInterval(this.timer);
  }
  initDate(t, e, i, s, r) {
    let o;
    return Utils.areNumericStrings(t, e, i) ? (o = new Date(Date.UTC(i, e - 1, t, s, r))) : ((o = new Date()).setHours(0, 0, 0, 0), o.setDate(o.getDate() + 1)), o.getTime();
  }
  addStateListener() {
    this.digits.forEach(digit => {
      digit.addEventListener("transitionend", ({ target }) => {
        if (target.getAttribute("data-transition-type") === "slide-out") {
          target.removeAttribute("data-transition-type");
        }
      });
    });
  }
  initTimer() {
    var t = new Date().getTime(),
        e = new Date(t).getTime();
    (this.distance = this.countdown_date - e), this.updateTime();
  }
  startTimer() {
    this.timer = setInterval(() => {
      (this.distance -= 1e3), this.updateTime();
    }, 1e3);
  }
  updateTime() {
    var t;
    this.checkIfFinished() || ((t = this.getDigits()), this.renderDigits(t));
  }
  checkIfFinished() {
    if (this.distance > 0) return false;

    clearInterval(this.timer);

    const container = this.closest("[data-countdown-container]");
    if (container) {
      if (this.hide_when_expired) {
        container.style.display = "none";
      }
      
      this.innerHTML = `<h3 class="offer_text">${this.show_button_when}</h3>`;
    }

    return true;
  }
  getDigits() {
    var t = Math.floor((this.distance % 6e4) / 1e3),
        e = 9 < t ? t.toString().split("").map(Number) : [0, t],
        i = Math.floor((this.distance % 36e5) / 6e4),
        s = 9 < i ? i.toString().split("").map(Number) : [0, i],
        r = Math.floor((this.distance % 864e5) / 36e5),
        o = 9 < r ? r.toString().split("").map(Number) : [0, r],
        a = Math.floor(this.distance / 864e5);
    return [...(99 < a ? [9, 9] : 9 < a ? a.toString().split("").map(Number) : [0, a]), ...o, ...s, ...e];
  }
  renderDigits(o) {
    this.days_container.setAttribute("aria-hidden", 0 === o[0] && 0 === o[1]),
        this.digits.forEach((t, e) => {
          var i,
              s,
              r = o[e];
          r !== parseInt(t.dataset.value) &&
              (t.setAttribute("data-value", r),
              (i = parseInt(t.getAttribute("data-index"))),
              t.setAttribute("data-index", (s = 0 === i ? 1 : 0)),
              (t.children[s].textContent = r),
              t.children[s].setAttribute("data-transition-type", "slide-in"),
              t.children[i].setAttribute("data-transition-type", "slide-out"));
        });
  }
}
customElements.define("countdown-timer", CountdownTimer);

if (window.location.pathname.indexOf('/products/') !== -1) {
  class ProductInfo extends HTMLElement {
    constructor() {
      super();
      this.products = JSON.parse(localStorage.getItem("recently-product")) || [];
      this.setRecentlyViewedProduct();
    }
    setRecentlyViewedProduct() {
      if(!this.products.includes(this.dataset.url)){
        this.products.unshift(this.dataset.url);
        localStorage.setItem("recently-product", JSON.stringify(this.products));
      }
    }
  }
  customElements.define('product-info',ProductInfo);
}

class RecentlyViewed extends HTMLElement {
  constructor() {
    super();
    this.products = JSON.parse(localStorage.getItem("recently-product"));
    this.wrapper = this.querySelector('#product-grid');
    this.count = 0;
    this.getRecentlyViewedProduct();
  }
  getRecentlyViewedProduct() {
    this.products.forEach((product,index) => {
      if(this.count > 3)
        return;
      if(product != this.dataset.currentHandle){
        this.getProductCard(product).then(data => {
          if(data !== undefined)
            this.wrapper.insertAdjacentHTML('beforeend', data);
        });
        this.count = this.count + 1;
      }else{
        return;
      }
    });
    if(this.products.length > 1)
      this.classList.remove("hidden");
  }
  getProductCard(handle){
    return fetch(`${handle}?view=recently-viewed`,{
      method:'GET'
    })
    .then(response => {
      if (!response.ok) {
          if (response.status === 404) {
              // console.log('Resource not found');
              return Promise.resolve(); // Skip further processing
          }
          throw new Error('Network response was not ok.');
      }
      return response.text();
    })
    .then(data => {
      return data;
    })
    .catch(error => console.log('Recently view error',error));
  }
}
customElements.define('recently-viewed',RecentlyViewed);

class ProductRecommendations extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    const handleIntersection = (entries, observer) => {
      if (!entries[0].isIntersecting) return;
      observer.unobserve(this);

      fetch(this.dataset.url)
        .then((response) => response.text())
        .then((text) => {
          const html = document.createElement('div');
          html.innerHTML = text;
          const recommendations = html.querySelector('product-recommendations');

          if (recommendations && recommendations.innerHTML.trim().length) {
            this.innerHTML = recommendations.innerHTML;
          }

          if (!this.querySelector('complementary-carousel') && this.classList.contains('complementary-products')) {
            this.remove();
          }

          if (html.querySelector('.complementary-slide')) {
            this.classList.add('product-recommendations--loaded');
          }
        })
        .catch((e) => {
          console.error(e);
        });
    };

    new IntersectionObserver(handleIntersection.bind(this), { rootMargin: '0px 0px 400px 0px' }).observe(this);
  }
}

customElements.define('product-recommendations', ProductRecommendations);

document.addEventListener("DOMContentLoaded", function () {
  let toTopBtn = document.getElementById("back-top__content--desk");

  if (!toTopBtn) return; // Exit if the button is not found 

  toTopBtn.addEventListener("click", function (e) {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  let scrollPos = 0;
  let backTop = document.getElementById("back-top");

  window.addEventListener("scroll", function () {
    let currentScroll = document.body.getBoundingClientRect().top;

    if (backTop) {
      if (currentScroll > scrollPos) {
        backTop.classList.remove("active");
      } else {
        backTop.classList.add("active");
      }
    }
    scrollPos = currentScroll;

    toTopBtn.style.bottom = window.scrollY > 500 ? "55px" : "-100px";
  });
});

document.querySelector(".drawer-page-content")?.addEventListener("click", function () {
  if (document.body.classList.contains("overflow-hidden-tablet")) {
    document.querySelector(".sidemenu-close")?.click();
  }
});

document.querySelector(".closeMenu")?.addEventListener("click", function () {
  if (document.body.classList.contains("overflow-hidden-tablet")) {
    document.querySelector(".sidemenu-close")?.click();
  }
});

document.querySelector(".overlay-click")?.addEventListener("click", function () {
  if (document.body.classList.contains("overflow-hidden-mobile")) {
    document.querySelector(".mobile-sidebar__close")?.click();
  }
});

/* change variant image on variant hover */

function delegateEvent(container, eventType, selector, handler) {
  container.addEventListener(eventType, function(event) {
    const target = event.target.closest(selector);
    if (target && container.contains(target)) handler.call(target, event);
  });
}

delegateEvent(document.body, 'mouseover', '.color-swatch', function() {
  const gridItem = this.closest('.swiper-slide, .grid__item');
  const cardWrapper = gridItem?.querySelector('.card-wrapper');
  if (cardWrapper) cardWrapper.classList.add('Change_variant');

  const img = document.querySelector('.Change_variant .media img');
  if (img) img.setAttribute("srcset", this.dataset.variantImage);
  
  this.classList.add('active');
  this.closest('.ProductItem__ColorSwatchItem')?.parentElement?.querySelectorAll('.color-swatch').forEach(el => {
    if (el !== this) el.classList.remove('active');
  });
});

delegateEvent(document.body, 'mouseout', '.color-swatch', function() {
  this.closest('.swiper-slide, .grid__item')?.querySelector('.card-wrapper')?.classList.remove('Change_variant');
});

class AddNote extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('click', (event) => {
      event.preventDefault();
      const addComment = document.getElementById('addComment');
      const cartDrawerItems = document.querySelector('cart-drawer-items');
      const cartDrawerFooter = document.querySelector('.cart-drawer__footer');

      addComment.classList.add('active');
      cartDrawerItems.classList.add('activeNote');
      cartDrawerFooter.classList.add('activeNote');
    });
  }
}
customElements.define('add-note', AddNote);

class CloseNote extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('click', (event) => {
      event.preventDefault();
      const addComment = document.getElementById('addComment');
      const cartDrawerItems = document.querySelector('cart-drawer-items');
      const cartDrawerFooter = document.querySelector('.cart-drawer__footer');

      addComment.classList.remove('active');
      cartDrawerItems.classList.remove('activeNote');
      cartDrawerFooter.classList.remove('activeNote');
    });
  }
}
customElements.define('close-note', CloseNote);

class ShopthelookBtn extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('click', (event) => {
      event.preventDefault();
      this.closest('.shop_media1').classList.toggle("is-active");
      this.classList.toggle("active");
    });
  }
}
customElements.define('shopthelook-btn', ShopthelookBtn);

class LookbookClose extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('click', (event) => {
      event.preventDefault();
      this.closest('.shop_media1').classList.toggle("is-active");
    });
  }
}
customElements.define('lookbook-close', LookbookClose);

document.querySelectorAll('input[type=radio][name=Color]').forEach(function(radio) {
  radio.addEventListener('change', function() {
    var checkedRadio = document.querySelector('.variant_name_color:checked');
    if (checkedRadio) {
      document.getElementById('data-variant-name').innerHTML = checkedRadio.value;
    }
  });
});

class CartPerformance {
  static #metric_prefix = "cart-performance"

  static createStartingMarker(benchmarkName) {
    const metricName = `${CartPerformance.#metric_prefix}:${benchmarkName}`
    return performance.mark(`${metricName}:start`);
  }

  static measureFromEvent(benchmarkName, event) {
    const metricName = `${CartPerformance.#metric_prefix}:${benchmarkName}`
    const startMarker = performance.mark(`${metricName}:start`, {
      startTime: event.timeStamp
    });

    const endMarker = performance.mark(`${metricName}:end`);

    performance.measure(
      benchmarkName,
      `${metricName}:start`,
      `${metricName}:end`
    );
  }

  static measureFromMarker(benchmarkName, startMarker) {
    const metricName = `${CartPerformance.#metric_prefix}:${benchmarkName}`
    const endMarker = performance.mark(`${metricName}:end`);

    performance.measure(
      benchmarkName,
      startMarker.name,
      `${metricName}:end`
    );
  }

  static measure(benchmarkName, callback) {
    const metricName = `${CartPerformance.#metric_prefix}:${benchmarkName}`
    const startMarker = performance.mark(`${metricName}:start`);

    callback();

    const endMarker = performance.mark(`${metricName}:end`);

    performance.measure(
      benchmarkName,
      `${metricName}:start`,
      `${metricName}:end`
    );
  }
}

class SwiperCarousel extends HTMLElement {
	constructor() {
		super();
		this.init();
		if (this.getAttribute('data-destroy') !== null) window.addEventListener('resize', debounce(() => {this.init()}, 15));
		this.addEventListener('mouseenter', () => {
			this.classList.remove('hover-off')
		});
		window.addEventListener('resize', debounce(() => {
			this.classList.remove('hover-off');
			if (this.carousel !== undefined) {
				this.checkScroll(this.carousel)
			}
		}, 100))
	}
	centerArrows() {
		const arrows = this.querySelector('.swiper-arrows-carousel'),
			imageContainer = this.querySelector('.image-container'),
			imageInside = this.querySelector('img');
		if (!arrows) return;
		if (imageContainer || imageInside) {
			let h = imageContainer ? imageContainer.offsetHeight/2 + 15 : imageInside.offsetHeight/2;
			if (this.querySelector('.prd-top')) {
				h += (this.querySelector('.prd-top').offsetHeight - 10)
			}
			arrows.style.setProperty('top', `${h}px`);
			arrows.style.setProperty('transform', 'none');
			this.querySelector('[data-load]')?.style.setProperty('top', `${h}px`);
		}
	}
	init() {
		this.getAttribute('data-destroy') !== null && this.destroy();
		const breakpoint = this.getAttribute('data-init-breakpoint');
		if (breakpoint !== null) {
			if (window.matchMedia(`(max-width:${+breakpoint}px)`).matches) {
				this.initSwiper()
			}
		} else this.initSwiper();
		this.querySelectorAll('.js-promoline-copy').forEach(el => {
			tippy(el, {
				content:el.getAttribute('data-tippy-text'),
				trigger:'click',
				animation:'scale',
				placement:'bottom',
				theme:'dark',
				touch: true
			})
		})
	}
	initSwiper() {
		const options_default = {
			touchRatio: 3,
			watchSlidesVisibility: true,
			on: {
				init: function(slider) {
					if (swiper.getAttribute('data-center-arrows') !== null) {
						swiper.centerArrows();
					}
					typeof Waypoint !== 'undefined' && Waypoint.refreshAll();
					swiper.querySelectorAll('product-card').forEach(element => {if ('productWidth' in element) element.productWidth()})
					const searchModal = swiper.closest('#searchModal');
					searchModal?.classList.add('swiper-visible');
					if (searchModal && searchModal.querySelector('.js-dropdn-content-scroll')) {
						Scrollbar.init(searchModal.querySelector('.js-dropdn-content-scroll'), {
							alwaysShowTracks: true,
							damping: document.body.dataset.damping
						})
					}
					const swiperWrapper = swiper.querySelector('.swiper-wrapper');
					if (swiperWrapper) {
						swiperWrapper.addEventListener('mousemove', debounce(() => {
							swiper.classList.remove('hover-off')
						}, 500))
						const observer = new MutationObserver(function (mutations) {
							mutations.forEach(function (mutation) {
								if (mutation.attributeName === 'style') {
									swiper.classList.add('hover-off')
								}
							})
						})
						const observerConfig = {
							attributes: true,
							attributeFilter: ['style'],
							childList: false,
							subtree: false,
						};
						observer.observe(swiperWrapper, observerConfig)
					}
					setTimeout(() => {
						swiper.classList.remove('hover-off')
					}, 100)
				},
				afterInit: (slider) => {
					this.checkScroll(slider)
				},
				slideChange: () => {
					this.querySelectorAll('*').forEach(node => {if (node._tippy) node._tippy.hide()})
				},
				touchStart: () => {
					if (!document.body.classList.contains('touch')) {
						if (this.querySelector('.lookbook-grid')) tippy.hideAll();
						this.querySelectorAll('*').forEach(node => {
							if (node._tippy) node._tippy.hide()
						})
					}
				},
				transitionEnd:() => {
					setTimeout(() => {
						swiper.classList.remove('hover-off');
					}, 100)
				}
			}
		}
		const swiper = this;
		if (this.getAttribute('data-filter-variable') !== null && this.closest('.js-category-page-block')) {
			const option = document.querySelector('.js-category-page-block').classList.contains('has-filter-closed') ? this.querySelector('.swiper-container ~ [data-filter-closed]').textContent : this.querySelector('.swiper-container ~ [data-filter-opened]').textContent;
			this.options = JSON.parse(option)
		} else {
			this.options = JSON.parse(this.querySelector('.swiper-container ~ [type="application/json"]').textContent)
		}
		if (this.options.pagination) {
			this.options.pagination['el'] = this.querySelector(this.options.pagination['el']);
		}

		if (this.options.navigation && !this.classList.contains('promoline-text')) {
			this.options.navigation['nextEl'] = this.querySelector(this.options.navigation['nextEl']);
			this.options.navigation['prevEl'] = this.querySelector(this.options.navigation['prevEl']);
		}
		// jq.extend(this.options, options_default);
		this.carousel = new Swiper(this.querySelector('.swiper-container'), this.options);
	}
	checkScroll(slider) {
		if (slider && slider.isBeginning && slider.isEnd) {
			this.querySelector('.swiper-container').classList.add('swiper-no-scroll')
		} else this.querySelector('.swiper-container').classList.remove('swiper-no-scroll')
	}
	destroy() {
		this.carousel !== undefined && this.carousel.destroy()
	}
	start() {
		this.carousel !== undefined && this.carousel.slideTo(0,0)
	}
}
customElements.define('swiper-carousel', SwiperCarousel);

/*** End Slider Code */