/* global SideDrawer */

if (!customElements.get('quick-add-drawer')) {
  class QuickAddDrawer extends SideDrawer {
    constructor() {
      super();
      this.content = this.querySelector('.js-product-details');
      this.form = this.querySelector('product-form');
      this.notification = this.querySelector('.js-added-to-cart');

      document.addEventListener('click', this.handleDocumentClick.bind(this));
      this.addEventListener('on:variant:change', this.handleVariantChange.bind(this));
    }

    /**
     * Handles 'click' events on the document.
     * @param {object} evt - Event object.
     */
    handleDocumentClick(evt) {
      if (!evt.target.matches('.js-quick-add')) return;
      this.open(evt.target);
    }

    /**
     * Handles 'on:variant:change' events on the Quick Add drawer.
     * @param {object} evt - Event object.
     */
    handleVariantChange(evt) {
      // Update product links
      let url = this.productUrl;
      if (evt.detail.variant) {
        const separator = this.productUrl.split('?').length > 1 ? '&' : '?';
        url += `${separator}variant=${evt.detail.variant.id}`;
      }
      this.querySelectorAll('.js-prod-link').forEach((link) => {
        link.href = url;
      });

      if (evt.detail.variant && evt.detail.variant.featured_media) {
        this.updateMedia(evt.detail.variant.featured_media);
      }
    }

    /**
     * Opens the drawer and fetches the product details.
     * @param {Element} opener - Element that triggered opening of the drawer.
     */
    async open(opener) {
      opener.setAttribute('aria-disabled', 'true');
      this.notification.hidden = true;

      // If it's the same product as previously shown, there's no need to re-fetch the details.
      if (this.productUrl && this.productUrl === opener.dataset.productUrl) {
        if (opener.dataset.selectedColor) this.setActiveVariant(opener);
        super.open(opener);
        opener.removeAttribute('aria-disabled');
        return;
      }

      this.productUrl = opener.dataset.productUrl;
      this.content.innerHTML = '';
      super.open(opener);

      const response = await fetch(opener.dataset.productUrl);
      if (response.ok) {
        const tmpl = document.createElement('template');
        tmpl.innerHTML = await response.text();
        this.productEl = tmpl.content.getElementById('quick-buy-template').content.querySelector('.js-product');
        this.renderProduct(opener);
      }

      opener.removeAttribute('aria-disabled');
    }

    /**
     * Renders the product details.
     * @param {Element} opener - Element that triggered opening of the drawer.
     */
    renderProduct(opener) {
      // Convert product template content to quick buy content.
      QuickAddDrawer.convertToQuickBuyContent(this.productEl);

      this.updateForm();
      this.updateContent(); // variant-picker requires form on initialisation

      // Update the product media.
      let colorImageSet = false;
      if (opener.dataset.selectedColor) {
        this.setActiveVariant(opener);
        if (this.currentMediaId) {
          colorImageSet = true;
        }
      }

      if (!colorImageSet) {
        const activeMedia = this.productEl.querySelector('.media-viewer__item.is-active');
        if (activeMedia) this.updateMedia(Number(activeMedia.dataset.mediaId));
      }
    }

    /**
     * Set color variant to match the one selected in the card.
     * @param {Element} opener - Element that triggered opening of the drawer.
     */
    setActiveVariant(opener) {
      this.querySelectorAll('.option-selector').forEach((optionSelector) => {
        const colorOption = optionSelector.querySelector(
          `.opt-btn[value="${CSS.escape(opener.dataset.selectedColor)}"]`
        );

        if (colorOption) {
          colorOption.click();
          return;
        }
        const firstBtn = optionSelector.querySelector('.opt-btn:not(.is-unavailable)');
        if (firstBtn && !firstBtn.checked) firstBtn.click();
      });
    }

    /**
     * Updates the product media.
     * @param {string} media - Variant featured media object.
     */
    updateMedia(media) {
      if (!media) return;

      const { src } = media.preview_image;

      const container = this.querySelector('.quick-add-info__media');
      const width = container.offsetWidth;
      const aspectRatio = media.preview_image.aspect_ratio;

      const existingId = container.dataset.mediaId;
      const existingImg = container.querySelector('img');

      if (!existingImg || existingId !== `${media.id}`) {
        container.innerHTML = `
          <img src="${src}&width=${width}" srcset="${src}&width=${width}, ${src}&width=${width * 2} 2x" width="${width * 2}" height="${(width * 2) / aspectRatio}" alt="${media.alt || ''}">
        `;
        container.dataset.mediaId = media.id;
      }
    }

    /**
     * Builds the markup for the drawer content element.
     */
    updateContent() {
      const productContent = this.productEl.querySelector('.js-product-details');
      if (productContent) {
        this.content.innerHTML = productContent.innerHTML;
      }

      this.classList.remove('is-loading');
      this.content.classList.remove('drawer__content--out');
    }

    /**
     * Updates the Quick Add drawer form (buy buttons).
     */
    updateForm() {
      const productForm = this.productEl.querySelector('product-form');

      if (productForm) {
        this.form.innerHTML = productForm.innerHTML;
        QuickAddDrawer.restoreScripts(this.form);
        this.form.init();

        if (Shopify && Shopify.PaymentButton) {
          Shopify.PaymentButton.init();
        }
      } else {
        this.form.innerHTML = '';
      }
    }

    /**
     * Gets the innerHTML of elements within the product element.
     * @param {string} selector - CSS selector for the element.
     * @param {...*} additionalSelectors - Additional CSS selectors for elements.
     * @returns {?string}
     */
    getElementHtml(selector, ...additionalSelectors) {
      const selectors = [selector].concat(additionalSelectors);
      let html = '';
      selectors.forEach((sel) => {
        const els = this.productEl.querySelectorAll(sel);
        Array.from(els).forEach((el) => {
          html += el.innerHTML;
        });
      });
      return html;
    }

    /**
     * Shows an "Added to cart" message in the drawer.
     */
    addedToCart() {
      this.notification.hidden = false;
    }

    /**
     * Replace script elements with new ones, thereby triggering a download.
     * @param {HTMLElement} el - Container to search for script elements.
     */
    static restoreScripts(el) {
      Array.from(el.querySelectorAll('script'))
        .forEach((oldScriptEl) => {
          const newScriptEl = document.createElement('script');

          Array.from(oldScriptEl.attributes).forEach((attr) => {
            newScriptEl.setAttribute(attr.name, attr.value);
          });

          const scriptText = document.createTextNode(oldScriptEl.innerHTML);
          newScriptEl.appendChild(scriptText);

          oldScriptEl.parentNode.replaceChild(newScriptEl, oldScriptEl);
        });
    }

    /**
     * Convert product template content to quick buy content.
     * @param {Element} container - Container element containing new content to use.
     */
    static convertToQuickBuyContent(container) {
      // Prevent variant picker from updating the URL on change.
      const variantPicker = container.querySelector('variant-picker');
      if (variantPicker) variantPicker.dataset.updateUrl = 'false';

      // Remove size chart modal and link (if they exist).
      const sizeChartModal = container.querySelector('[data-modal^="size-chart-"]');
      const sizeChartDialog = container.querySelector('[id^="size-chart-"]');

      if (sizeChartModal) sizeChartModal.remove();
      if (sizeChartDialog) sizeChartDialog.remove();
    }
  }

  customElements.define('quick-add-drawer', QuickAddDrawer);

  window.theme = window.theme || {};
  window.theme.quickBuy = window.theme.quickBuy || {};
  window.theme.quickBuy.convertToQuickBuyContent = QuickAddDrawer.convertToQuickBuyContent;
}
