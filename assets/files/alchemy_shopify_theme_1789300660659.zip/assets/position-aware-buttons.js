const colorMapEnter = {
  'btn--primary': 'rgb(var(--btn-bg-color))',
  'btn--secondary': 'rgba(var(--btn-alt-bg-color) / var(--btn-alt-bg-alpha))',
  'btn--hollow': 'rgb(var(--btn-bg-color))'
};

const colorMapLeave = {
  'btn--primary': 'rgb(var(--btn-text-color))',
  'btn--secondary': 'rgb(var(--btn-alt-text-color))',
  'btn--hollow': 'currentColor'
};

/**
 * Create a span on position aware button
 * Set position based on mouse event
 */
function initPositionAwareButtons() {
  if (!window.matchMedia('(hover: hover)').matches || !document.querySelector('.btn.btn--position-aware')) return;

  const setBtnBackground = (evt) => {
    const btn = evt.currentTarget;
    const rect = btn.getBoundingClientRect();
    const x = evt.pageX - rect.left - window.scrollX;
    const y = evt.pageY - rect.top - window.scrollY;
    const size = Math.sqrt(rect.width ** 2 + rect.height ** 2);

    btn.style.setProperty('--pos-aware-x', `${x}px`);
    btn.style.setProperty('--pos-aware-y', `${y}px`);
    btn.style.setProperty('--pos-aware-size', `${size}px`);
    btn.style.setProperty('--pos-aware-scale', '2');
  };

  const setBtnColor = (btn, map) => {
    Object.keys(map).forEach((btnClass) => {
      if (btn.classList.contains(btnClass)) btn.style.color = map[btnClass];
    });
  };

  const resetButton = (btn) => {
    btn.removeEventListener('mousemove', setBtnBackground);
    btn.style.setProperty('--pos-aware-scale', '0');
    setBtnColor(btn, colorMapLeave);
  };

  document.addEventListener('mouseenter', (evt) => {
    if (!(evt.target instanceof Element)) return;
    const btn = evt.target.closest('.btn.btn--position-aware');
    if (!btn) return;

    if (!btn.querySelector('.js-position-aware')) {
      const span = document.createElement('span');
      span.className = 'js-position-aware';
      btn.appendChild(span);
    }

    btn.addEventListener('mousemove', setBtnBackground);
    setBtnColor(btn, colorMapEnter);
  }, true);

  ['mouseleave', 'click'].forEach((event) => {
    document.addEventListener(event, (evt) => {
      if (!(evt.target instanceof Element)) return;
      const btn = evt.target.closest('.btn.btn--position-aware');
      if (!btn) return;
      resetButton(btn);
    }, true);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initPositionAwareButtons();
});
